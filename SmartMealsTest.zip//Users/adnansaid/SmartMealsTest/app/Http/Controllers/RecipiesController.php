<?php

namespace App\Http\Controllers;

use App\Recipies;
use Illuminate\Http\Request;

class RecipiesController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Recipies  $recipies
     * @return \Illuminate\Http\Response
     */
    public function show(Recipies $recipies)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Recipies  $recipies
     * @return \Illuminate\Http\Response
     */
    public function edit(Recipies $recipies)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Recipies  $recipies
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Recipies $recipies)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Recipies  $recipies
     * @return \Illuminate\Http\Response
     */
    public function destroy(Recipies $recipies)
    {
        //
    }
}
