<?php $__env->startComponent('mail::message'); ?>
Welcomw to Smart Meals

We eat food too! Thanks for joining our community. Here we will work together to create recipes together,
share with our friends and essentially create the perfect meal!

Are you ready?

<?php $__env->startComponent('mail::button', ['url' => '']); ?>
Button Text
<?php if (isset($__componentOriginalb8f5c8a6ad1b73985c32a4b97acff83989288b9e)): ?>
<?php $component = $__componentOriginalb8f5c8a6ad1b73985c32a4b97acff83989288b9e; ?>
<?php unset($__componentOriginalb8f5c8a6ad1b73985c32a4b97acff83989288b9e); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>

All the best,<br>
Adnan Said
<?php if (isset($__componentOriginal2dab26517731ed1416679a121374450d5cff5e0d)): ?>
<?php $component = $__componentOriginal2dab26517731ed1416679a121374450d5cff5e0d; ?>
<?php unset($__componentOriginal2dab26517731ed1416679a121374450d5cff5e0d); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php /**PATH /Users/adnansaid/SmartMeals/resources/views/emails/welcome-email.blade.php ENDPATH**/ ?>