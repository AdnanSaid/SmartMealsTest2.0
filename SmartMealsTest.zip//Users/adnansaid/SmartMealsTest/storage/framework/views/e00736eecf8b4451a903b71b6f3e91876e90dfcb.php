<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-3 pt-5">
            <img src=>
        </div>
        <div class="col-9 pt-5">
            <div class="d-flex justify-content-between align-items-baseline">
                <h1><?php echo e($user -> username); ?></h1>
                <a href="#">Add New Post</a>

            </div>
            <div class = "d-flex">
                <div class="pr-5 "><strong>0 </strong> meal plans</div>
                <div class="pr-5 "><strong>0 </strong> recipes</div>
                <div class="pr-5 "><strong>0 </strong> followers</div>
                <div class="pr-5 "><strong>0 </strong> following</div>
            </div>
            <div class="pt-4 font-weight-bold"><?php echo e($user->profile->title); ?></div>
            <div><?php echo e($user->profile->description); ?></div>
            <div><a href="#"><?php echo e($user->profile->url); ?></a></div>
        </div>
    </div>

    <div class="row pt-5">
        <div class="col-4">
            <img src= class="w-100">
            </div>
        <div class="col-4">
            <img src= class="w-100">
        </div>
        <div class="col-4">
            <img src= class="w-100">
        </div>

    </div>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/adnansaid/SmartMeals/resources/views/home.blade.php ENDPATH**/ ?>