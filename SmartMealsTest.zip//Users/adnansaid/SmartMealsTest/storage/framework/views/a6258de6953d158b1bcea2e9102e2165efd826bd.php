<?php echo e($slot); ?>

<?php /**PATH /Users/adnansaid/SmartMealsTest/vendor/laravel/framework/src/Illuminate/Mail/resources/views/text/footer.blade.php ENDPATH**/ ?>