<?php $__env->startSection('content'); ?>

    <h1 class="text-center">Step 1- Add New Recipe</h1>
    <hr>
    <form action="/recipes/create-step1" method="post">

        <?php echo e(csrf_field()); ?>


    <div class="container">
        <div class="row">
            <div class="col-8 offset-2">

                <div class="row">
                    <h1>Add New Recipe</h1>
                </div>

                <div class="form-group row">

                    <label for="title" class="col-md-4 col-form-label">Recipe Title</label>

                    <input id="title"
                           type="text"
                           class="form-control<?php echo e($errors->has('title') ? ' is-invalid' : ''); ?>"
                           name="title"
                           value="<?php echo e(old('title')); ?>"
                           autocomplete="title" autofocus>



                    <?php if($errors->has('title')): ?>
                        <span class="invalid-feedback" role="alert">
                            <strong><?php echo e($errors->first('title')); ?></strong>
                        </span>
                    <?php endif; ?>
                </div>

                <hr>

                <section class="Description">
                    <div class="form-group row">
                        <label for="description" class="col-md-4 col-form-label">Recipe Description</label>

                        <textarea class="form-control <?php echo e($errors->has('description') ? ' is-invalid' : ''); ?>"
                                  name="body"
                                  id="description"
                                  rows="5"
                                  placeholder="Your Post Here"
                                  value="<?php echo e(old('description')); ?>"
                                  autocomplete="description" autofocus>
                        </textarea>

                        <?php if($errors->has('description')): ?>
                            <span class="invalid-feedback" role="alert">
                            <strong><?php echo e($errors->first('description')); ?></strong>
                        </span>
                        <?php endif; ?>

                    </div>
                </section>

                <hr>

                <button type="submit" class="btn btn-primary">Add Product Image</button>

            </div>
        </div>
    </div>
    </form>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/adnansaid/SmartMealsTest/resources/views/recipes/create-step1.blade.php ENDPATH**/ ?>