<?php $__env->startSection('content'); ?>

    <h1 class="text-center">Step 2- Add Recipe Image</h1>
    <hr>
    <?php if(isset($recipe->productImg)): ?>
        Product Image:
        <img alt="Product Image" src="/storage/productimg/<?php echo e($product->productImg); ?>"/>
    <?php endif; ?>
    <form action="/recipes/create-step2" method="post">

        <?php echo e(csrf_field()); ?>


    <div class="container">
        <div class="row">
            <div class="col-8 offset-2">

                <div class="row">
                    <h1>Add Image of dish</h1>
                </div>

                <hr>

                <section class="class">

                    <div class="row">
                        <label for="image" class="col-md-4 col-form-label">Post Image</label>

                        <input type="file" class="form-control-file" id="image" name="image">

                        <?php if($errors->has('image')): ?>
                            <strong><?php echo e($errors->first('image')); ?></strong>
                        <?php endif; ?>
                    </div>
                </section>

                <hr>

                <button type="submit" class="btn btn-primary">Add Ingredients</button>


            </div>
        </div>
    </div>
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/adnansaid/SmartMealsTest/resources/views/recipes/create-step2.blade.php ENDPATH**/ ?>