<?php $__env->startSection('content'); ?>
    <div class="container">

        <div class="row">
            <div class="col-8 offset-2">

                <div class="row">
                    <h1>Add New Post</h1>
                </div>
                <div class="form-group row">
                    <label for="caption" class="col-md-4 col-form-label">Post Ingredients</label>

                    <input id="caption"
                           type="text"
                           class="form-control<?php echo e($errors->has('caption') ? ' is-invalid' : ''); ?>"
                           name="caption"
                           value="<?php echo e(old('caption')); ?>"
                           autocomplete="caption" autofocus>

                    <?php if($errors->has('caption')): ?>
                        <span class="invalid-feedback" role="alert">
                            <strong><?php echo e($errors->first('caption')); ?></strong>
                        </span>
                    <?php endif; ?>
                </div>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/adnansaid/SmartMeals/resources/views/post_recipes/create.blade.php ENDPATH**/ ?>