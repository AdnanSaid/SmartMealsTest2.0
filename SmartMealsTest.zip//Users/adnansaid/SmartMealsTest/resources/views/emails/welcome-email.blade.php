@component('mail::message')
Welcomw to Smart Meals

We eat food too! Thanks for joining our community. Here we will work together to create recipes together,
share with our friends and essentially create the perfect meal!

Are you ready?

@component('mail::button', ['url' => ''])
Button Text
@endcomponent

All the best,<br>
Adnan Said
@endcomponent
